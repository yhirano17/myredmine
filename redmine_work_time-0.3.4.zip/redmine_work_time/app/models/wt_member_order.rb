class WtMemberOrder < ActiveRecord::Base
  attr_accessible :user_id, :position, :prj_id
end
