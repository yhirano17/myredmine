class WtHolidays < ActiveRecord::Base
  attr_accessible :holiday, :created_on, :created_by
end
