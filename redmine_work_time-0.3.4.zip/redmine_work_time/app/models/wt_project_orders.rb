class WtProjectOrders < ActiveRecord::Base
  attr_accessible :uid, :dsp_prj, :dsp_pos
end
