require File.dirname(__FILE__) + '/../test_helper'

class WtTicketRelayTest < Test::Unit::TestCase
  fixtures :wt_ticket_relays

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
